#include "chiffrement.h"

int CLE = CLE_DEFAUT;

void crypto_initialiser_cle(int cle)
{
    CLE = cle;
}

void crypto_chiffrer(CH50 chaine)
{
    printf("REMPLACEZ-MOI ! La chaine est %s\n", chaine);
//  retirer cette ligne une fois que vous avez commencé à écrire le code de cette fonction. 
    A_FAIRE();
}

void crypto_dechiffrer(CH50 chaine)
{
    printf("REMPLACEZ-MOI ! La chaine est %s\n", chaine);
//  retirer cette ligne une fois que vous avez commencé à écrire le code de cette fonction. 
    A_FAIRE();
}


